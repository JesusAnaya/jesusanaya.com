tinyMCE.addI18n('en.example_dlg',{
	title : 'Insert Your source code here'
});
