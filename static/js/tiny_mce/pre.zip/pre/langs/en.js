tinyMCE.addI18n('en.pre',{
	desc : 'This plugin will propertly insert your code'
});
